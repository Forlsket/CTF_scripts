text = "DR=="
print(text.decode('base64').encode('base64'))