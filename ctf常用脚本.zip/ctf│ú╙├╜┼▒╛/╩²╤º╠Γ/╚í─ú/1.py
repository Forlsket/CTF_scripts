flag=0
j = 0
for i in range(19260817):
    flag = (flag*10+2)%1000000007

print('end:   ',flag)