m =2
for i in range(19260816):
	m  = m*10+2
	m %= 1000000007
print(m)