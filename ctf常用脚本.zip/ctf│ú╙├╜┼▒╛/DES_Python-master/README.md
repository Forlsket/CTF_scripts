DES_Python
==========

des.py用于加密，des_1.py用于des解密！

详情： http://my.oschina.net/liupengs/blog/124230