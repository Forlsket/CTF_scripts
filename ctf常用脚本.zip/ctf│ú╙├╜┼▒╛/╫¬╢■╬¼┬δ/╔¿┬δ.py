import zxing
reader = zxing.BarCodeReader()
barcode = reader.decode("3.png")
print(barcode.parsed)


