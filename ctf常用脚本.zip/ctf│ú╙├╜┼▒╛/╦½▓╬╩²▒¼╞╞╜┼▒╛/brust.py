import requests

url = "http://202.38.93.111:10888/invite/7cd76128-7f69-43c9-82a7-0ca78c94ccac"

