from scapy.all import *

packets = rdpcap('帮帮小明.pcapng')

for packet in packets:
    if packet.haslayer(TCP):
        if packet[TCP].type == 0:
            print packet[TCP].load[-8:]
